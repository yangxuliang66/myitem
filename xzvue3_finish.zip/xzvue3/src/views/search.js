import { ref, watch } from "vue"

export default ()=>{
  let kw=ref("");
  var search=()=>{
    if(kw.value.trim()!==""){
      console.log(`搜索 ${kw.value.trim()} 相关的内容...`)
    }
  };
  watch(kw,()=>{
    search();
  })
  return { kw, search }
}