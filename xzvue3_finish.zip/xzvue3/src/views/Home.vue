<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <div>
      <button @click="minus">-</button>
      <span>{{n}}</span>
      <button @click="add">+</button>
    </div>
    <div>
      <ul>
        <li v-for="(t,i) of arr" :key="i" @click="change(i)">
          {{i+1}} - {{t}}
        </li>
      </ul>
    </div>
    <div>
      <input v-model="kw" v-my-focus type="text" name="" id="">
      <button @click="search">百度一下</button>
    </div>
    <div>
      <ul>
        <li v-for="p of cart" :key="p.pid">
          {{p.pid}} | {{p.pname}} | ¥{{p.price.toFixed(2)}} | {{p.count}} | 小计:¥{{(p.price*p.count).toFixed(2)}}
        </li>
      </ul>
      <h3>总计:¥{{total.toFixed(2)}}</h3>
    </div>
    <h3>性别:{{sexFilter}}</h3>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, toRefs, watch , computed} from 'vue';
import counter from "./counter.js"
import search from "./search.js"

export default defineComponent({
  name: 'Home',
  directives:{
    "my-focus":{
      mounted(元素对象){
        元素对象.focus();
      }
    }
  },
  setup(){
    //创建一个支持响应式的受监控的变量n
    const data=ref({
      sex:1,
      arr:["亮亮","然然","东东"],
      cart:[
        {pid:1, pname:"华为",price:9588,count:2},
        {pid:2, pname:"苹果",price:10588,count:1},
        {pid:3, pname:"小米",price:6588,count:3},
      ]
    });
    //将data中的n和arr重新解构出来单独使用
    let {arr,cart,sex}=toRefs(data.value);
    const methods={
      change(i:number){
        if(arr.value[i]=="东东"){
          arr.value[i]="❀";
        }else{
          arr.value[i]="逝去了";
        }
      },
      total:computed(()=>{
        var sum=0;
        for(var p of cart.value){
          sum+=p.price*p.count
        }
        return sum;
      }),
      sexFilter:computed(()=>{
        return sex.value==1?"男":"女"
      })
    }

    //必须将要用到界面上的所有变量和方法都返回出来
    return {
      ...toRefs(data.value), ...methods,
      ...counter(),
      ...search()
    }
  }
});
</script>
