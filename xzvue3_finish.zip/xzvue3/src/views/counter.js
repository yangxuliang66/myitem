import {ref} from "vue"

export default ()=>{
  let n=ref(0);
  var add=()=>{
    n.value++;
  }
  var minus=()=>{
    if(n.value>0){
      n.value--;
    }
  }
  return { n, add, minus }
}