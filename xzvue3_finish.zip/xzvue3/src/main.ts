import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios';
import MyNav from "./components/Nav.vue"

axios.defaults.baseURL="/"
var app=createApp(App);
// //创建全局指令
// app.directive("my-focus",{
//   mounted(元素对象){
//     元素对象.focus();
//   }
// })
app.component("my-nav",MyNav);
app.use(store).use(router).mount('#app')
